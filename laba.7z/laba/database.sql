-- MySQL schema for the site
-- Compatible with MySQL 8.x (InfinityFree)
-- How to use:
-- 1) Open your hosting control panel -> phpMyAdmin
-- 2) Select database `if0_40067151_XXX`
-- 3) Import this file

-- Use your existing database (created by host)
USE `if0_40067151_XXX`;

-- Recommended SQL modes and charset
SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;
SET collation_connection = 'utf8mb4_unicode_ci';
SET SQL_SAFE_UPDATES = 0;

-- Drop tables in reverse dependency order for clean re-imports
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `bookings`;
DROP TABLE IF EXISTS `time_slots`;
DROP TABLE IF EXISTS `reviews`;
DROP TABLE IF EXISTS `quests`;
DROP TABLE IF EXISTS `users`;
SET FOREIGN_KEY_CHECKS = 1;

-- Users registered via register.html
CREATE TABLE `users` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(50) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_users_username` (`username`),
  UNIQUE KEY `uk_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Quests listed on quest.html
CREATE TABLE `quests` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(150) NOT NULL,
  `slug` VARCHAR(160) GENERATED ALWAYS AS (replace(lower(`title`), ' ', '-')) VIRTUAL,
  `description` TEXT NULL,
  `image_path` VARCHAR(255) NULL,
  `price` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `duration_minutes` INT UNSIGNED NOT NULL DEFAULT 60,
  `difficulty` ENUM('easy','medium','hard') NOT NULL DEFAULT 'medium',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_quests_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Reviews submitted on reviews.html (by user or guest)
CREATE TABLE `reviews` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NULL,
  `quest_id` BIGINT UNSIGNED NULL,
  `name` VARCHAR(100) NOT NULL,
  `rating` TINYINT UNSIGNED NOT NULL,
  `comment` TEXT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_reviews_quest_id` (`quest_id`),
  KEY `idx_reviews_user_id` (`user_id`),
  CONSTRAINT `chk_reviews_rating_range` CHECK (`rating` BETWEEN 1 AND 5),
  CONSTRAINT `fk_reviews_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_reviews_quest` FOREIGN KEY (`quest_id`) REFERENCES `quests` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Time slots for scheduling (used by schedule.html)
CREATE TABLE `time_slots` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `quest_id` BIGINT UNSIGNED NOT NULL,
  `start_at` DATETIME NOT NULL,
  `end_at` DATETIME NOT NULL,
  `is_booked` TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_time_slots_quest_start` (`quest_id`, `start_at`),
  KEY `idx_time_slots_quest` (`quest_id`),
  CONSTRAINT `chk_time_slots_range` CHECK (`end_at` > `start_at`),
  CONSTRAINT `fk_time_slots_quest` FOREIGN KEY (`quest_id`) REFERENCES `quests` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bookings created by users or guests for a quest/time slot
CREATE TABLE `bookings` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT UNSIGNED NULL,
  `quest_id` BIGINT UNSIGNED NOT NULL,
  `time_slot_id` BIGINT UNSIGNED NULL,
  `customer_name` VARCHAR(120) NOT NULL,
  `customer_phone` VARCHAR(30) NULL,
  `customer_email` VARCHAR(255) NULL,
  `status` ENUM('pending','confirmed','cancelled','completed') NOT NULL DEFAULT 'pending',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_bookings_user` (`user_id`),
  KEY `idx_bookings_quest` (`quest_id`),
  KEY `idx_bookings_time_slot` (`time_slot_id`),
  CONSTRAINT `fk_bookings_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_bookings_quest` FOREIGN KEY (`quest_id`) REFERENCES `quests` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_bookings_slot` FOREIGN KEY (`time_slot_id`) REFERENCES `time_slots` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Optional seed data you can remove/adjust
INSERT INTO `quests` (`title`, `description`, `image_path`, `price`, `duration_minutes`, `difficulty`)
VALUES
  ('Тайна Джокера', 'Выберитеcь из логова Джокера за 60 минут.', 'assets/img/joker.jpg', 49.99, 60, 'medium');

-- Example time slots for the sample quest (today + times)
INSERT INTO `time_slots` (`quest_id`, `start_at`, `end_at`)
SELECT q.id, CONCAT(CURDATE(), ' 12:00:00'), CONCAT(CURDATE(), ' 13:00:00') FROM quests q WHERE q.title = 'Тайна Джокера';
INSERT INTO `time_slots` (`quest_id`, `start_at`, `end_at`)
SELECT q.id, CONCAT(CURDATE(), ' 14:00:00'), CONCAT(CURDATE(), ' 15:00:00') FROM quests q WHERE q.title = 'Тайна Джокера';


